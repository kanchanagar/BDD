package com.pageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.StepDefinition.TestBase;


public class AmazonSearchPage{
	static WebDriver driver = TestBase.driver;
	

	public static WebElement getSearchBox() {
		return driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));
	}

	public static WebElement getSearchIcon() {
		return driver.findElement(By.xpath("//input[@id='nav-search-submit-button']"));
	}
	
	public static WebElement clickOnTheFirstResult() {
		return driver.findElement(By.xpath("(//img[@class='s-image'])[1]"));
	}

	public static WebElement getTheResultTable() {
		return driver.findElement(By.xpath("//th[normalize-space()='ASIN']//following-sibling::td"));
	}
}
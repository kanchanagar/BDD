package com.StepDefinition;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.pageObjectModel.AmazonSearchPage;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchAmazon{
	WebDriver driver = TestBase.driver;
	
	@Given("Navigate to Amazon Page")
	public void navigate_to_amazon_page() {
	    try {
			driver.get("https://www.amazon.in/");
			System.out.println("Entered into Amazon Webpage");
			driver.manage().window().maximize();
		} catch (Exception e) {
			System.out.println("Unable to get into Amazon Webpage");
			e.printStackTrace();
			
		}
	}
	

	@Given("Enter the Input term to be searched {string}")
	public void enter_the_input_term_to_be_searched(String string) {
		try {
			System.out.println(string);
	    	WebElement searchBox = AmazonSearchPage.getSearchBox();
	    	searchBox.click();
	    	searchBox.sendKeys(string);
	    }
	    catch(Exception e) {
	    	System.out.println("Unable to send Search Term");
	    	e.printStackTrace();
	    }
	}



	
	@Given("Click on search button")
	public void click_on_search_button() {
	    try {
			WebElement searchIcon = AmazonSearchPage.getSearchIcon();
			searchIcon.click();
			System.out.println("clicked on SearchIcon");
		} catch (Exception e) {
			System.out.println("Unable click on SearchIcon");
			e.printStackTrace();
			
		}
	}
	
	@Given("Click on the first result")
	public void click_on_the_first_result() {
	    try {
			WebElement resultClick = AmazonSearchPage.clickOnTheFirstResult();
			resultClick.click();
			Thread.sleep(3000);
			System.out.println("clicked on First Result");
		} catch (Exception e) {
			System.out.println("Unable click on First Result");
			e.printStackTrace();
			
		}
	}
	
	@Given("Scroll to the botton") 
	public void scroll_to_the_botton() {
	    try {
	    	ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs.get(1));
	    	WebElement element = AmazonSearchPage.getTheResultTable();
	    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	    	Thread.sleep(2000);
	    }
	    catch(Exception e) {
	    	System.out.println("Unable to scroll to the element");
	    	e.printStackTrace();
	    	
	    }
	}
	@Given("Validate the term in the table {string}.")
	public void validate_the_term_in_the_table(String compareElement) {
	    try {
			WebElement tableValue = AmazonSearchPage.getTheResultTable();
			String actual = tableValue.getText();
			if(compareElement.contains(actual)) {
				Assert.assertTrue(true);
				System.out.println("Validated Successfully");
			}
			else
				Assert.assertTrue(false);
		} catch (Exception e) {
			System.out.println("Validated Successfully");
			e.printStackTrace();
		}
	}

	
	





}

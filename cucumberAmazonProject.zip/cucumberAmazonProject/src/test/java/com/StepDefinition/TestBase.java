package com.StepDefinition;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class TestBase{
	public static WebDriver driver;
	
	@Before
	public static WebDriver getDriver() {
		WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver();
		 return driver;
		
	}
	
	@After
	public static void afterSuite() {
		driver.quit();
	}
	
}